package com.trainee.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.staticdb.StaticDb;

public class TraineeDaoImpl implements ITraineeeDao {

	static HashMap<Integer,TraineeBean> traineeMap = StaticDb.getTraineeMap();
	
	@Override
	public List<TraineeBean> getAllTrainees() {
		List<TraineeBean> trainees = new ArrayList<TraineeBean>(traineeMap.values());
		return trainees;
	}

	@Override
	public TraineeBean getTrainee(int id) {
		TraineeBean traineeBean = traineeMap.get(id);
		return traineeBean;
	}

	public TraineeBean updateCountry(TraineeBean trainee) {
		if (trainee.getTraineeId() <= 0)
			return null;
		traineeMap.put(trainee.getTraineeId(), trainee);
		return trainee;
	}
	
	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		traineeMap.put(trainee.getTraineeId(), trainee);
		return trainee;
	}

	@Override
	public TraineeBean deleteTrainee(int id) {
		return traineeMap.remove(id);
	}

}
