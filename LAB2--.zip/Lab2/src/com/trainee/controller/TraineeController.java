package com.trainee.controller;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class TraineeController {


	


	
	
		@RequestMapping("show")
		public String showHomePage()
		{
			return ("index");
		}
		
		@RequestMapping("update")
		public ModelAndView updateEmployee(@ModelAttribute("emp")@Valid EmployeeBean bean, BindingResult result,Model model)
		{
			ModelAndView mv=new ModelAndView();
			if(result.hasErrors())
			{
				mv.setViewName("updateemp");
				mv.addObject("emp", bean);
			}
			else{
			mv.setViewName("updateemp");
			mv.addObject("emp", bean);
			}
			return(mv);
			
			
		}
		
		@RequestMapping(value="addemployee",method=RequestMethod.POST)
		public String addEmployee(@ModelAttribute("emp") EmployeeBean bean, BindingResult result,Model model)
		{
			if(result.hasErrors())
			{
				model.addAttribute("message",result);
				return ("error");
			}
			
			return ("success");
			
		}

		@RequestMapping("/viewAll")
		public ModelAndView viewAllEmployee()
		{
			
			
			EmployeeBean e1=new EmployeeBean(1001,"John");
			EmployeeBean e2=new EmployeeBean(1002,"Jacob");
			EmployeeBean e3=new EmployeeBean(1003,"Smith");
			list.add(e1);
			list.add(e2);
			list.add(e3);
			ModelAndView model=new ModelAndView();
			model.setViewName("viewAll");
			model.addObject("list", list);
			return(model);
			
			
		}
		
	}


}
