package com.trainee.dao;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeeDao {

	


	public int addTrainee(TraineeBean bean)throws TraineeException;
	
	public List<TraineeBean> viewAllTrainee()throws TraineeException;
	
	public TraineeBean deleteTrainee(int employeeId)throws TraineeException;
	
	public boolean updateTrainee(TraineeBean bean)throws TraineeException;
	

}
