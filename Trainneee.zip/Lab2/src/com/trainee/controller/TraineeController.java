package com.trainee.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
import com.trainee.service.ITraineeService;
@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;
	
	
	@RequestMapping("showHomePage")
	public String  showHomePage()
	{
		return("index");
	}
	@RequestMapping("add")
	public String  showAdd()
	{
		return("addTrainee");
	}
	
	@RequestMapping(value="addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") TraineeBean bean,BindingResult result)
 	{
		ModelAndView mv=new ModelAndView();
		if(result.hasErrors())	
		{
			mv.setViewName("error");
			mv.addObject("message","Binding Failed");
		}
		else {
			try {
				int id=traineeService.addTrainee(bean);
				mv.setViewName("success");
				mv.addObject("id",id);
				mv.addObject("trainee",bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message",e.getMessage());
			}
			
		}

		
		
		return(mv);
	}
	@RequestMapping("showAll")
	public ModelAndView showAllEmployees()
	{
		ModelAndView mv=new ModelAndView();
		try {
			
			List<TraineeBean> list=traineeService.viewAllTrainees();
			mv.setViewName("viewAll");
			mv.addObject("list",list);
			
		} catch (TraineeException e) {
			
			mv.setViewName("error");
			mv.addObject("message",e.getMessage());
		}
		
		
		return mv;
	}
	@RequestMapping("delete")
	public ModelAndView deleteTrainee(@ModelAttribute("emp") TraineeBean bean,BindingResult result)
	{
		ModelAndView mv=new ModelAndView();
		try {
			TraineeBean beann=traineeService.deleteTrainee(bean.getTraineeId());
		if(bean!=null){
		
		mv.setViewName("success");
		mv.addObject("emp",beann);
		}
		/*else {
			mv.setViewName("error");
			mv.addObject("message","could not delete");
		}*/
		} catch (TraineeException e){
			
			mv.setViewName("error");
			mv.addObject("message",e.getMessage());
		}
		return mv;
	}
	
	@RequestMapping("update")
	public ModelAndView updateTrainee(@ModelAttribute("emp")@Valid TraineeBean bean, BindingResult result,Model model)
	{
		ModelAndView mv=new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			
		}
		else{
		mv.setViewName("update");
		mv.addObject("emp", bean);
		}
		return(mv);
		
	}
	
	
	@RequestMapping("update1")
	public ModelAndView updateTrainee(@ModelAttribute("emp") TraineeBean bean,BindingResult result)
	{
		ModelAndView mv=new ModelAndView();
		try {
		boolean isUpdate=traineeService.updateTrainee(bean);
		if(isUpdate){
		List<TraineeBean> list=traineeService.viewAllTrainees();
		mv.setViewName("viewAll");
		mv.addObject("list",list);
		}
		else {
			mv.setViewName("error");
			mv.addObject("message","could not update");
		}
		} catch (TraineeException e){
			
			mv.setViewName("error");
			mv.addObject("message",e.getMessage());
		}
		return mv;
	}
	
	}


