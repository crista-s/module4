package com.author.dao;

import java.util.List;

import com.author.bean.AuthorBean;
import com.author.exception.AuthorException;

public interface IAuthorDao {

	public int addAuthor (AuthorBean author) throws AuthorException;
	
	public AuthorBean deleteAuthor(int authorId)throws AuthorException;
	
	public AuthorBean findAuthor(int authorId)throws AuthorException;
	
	public List viewAllAuthors()throws AuthorException;
	
	public AuthorBean updateAuthor(int authorId,int phone)throws AuthorException;
}
