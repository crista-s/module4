package com.author.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="author_tbl")
//@NamedQuery(name="viewAllEmployee", query="from Employee")
public class AuthorBean {
	
	
		
		@Id //primary key
		@GeneratedValue(strategy=GenerationType.AUTO)//default strategy is auto,this is how we do it explicitly
		@Column(name="author_id")
		private int authorId;
		
		@Column(name="author_firstname",length=15)
		private String authorFirstName;
		
		@Column(name="author_middlename",length=15)
		private String authorMiddleName;
		
		@Column(name="author_lastname",length=15)
		private String authorLastName;
		
		@Column(name="author_phone")
	
		private int authorPhone;
		
		

		public AuthorBean() {
			super();
		}
		
		

		public AuthorBean(int authorId, String authorFirstName,
				String authorMiddleName, String authorLastName, int authorPhone) {
			super();
			this.authorId = authorId;
			this.authorFirstName = authorFirstName;
			this.authorMiddleName = authorMiddleName;
			this.authorLastName = authorLastName;
			this.authorPhone = authorPhone;
		}



		public int getAuthorId() {
			return authorId;
		}

		public void setAuthorId(int authorId) {
			this.authorId = authorId;
		}

		public String getAuthorFirstName() {
			return authorFirstName;
		}

		public void setAuthorFirstName(String authorFirstName) {
			this.authorFirstName = authorFirstName;
		}

		public String getAuthorMiddleName() {
			return authorMiddleName;
		}

		public void setAuthorMiddleName(String authorMiddleName) {
			this.authorMiddleName = authorMiddleName;
		}

		public String getAuthorLastName() {
			return authorLastName;
		}

		public void setAuthorLastName(String authorLastName) {
			this.authorLastName = authorLastName;
		}

		public int getAuthorPhone() {
			return authorPhone;
		}

		public void setAuthorPhone(int authorPhone) {
			this.authorPhone = authorPhone;
		}
		
}
