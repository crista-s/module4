package com.trainee.service;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeService {
	public int addTrainee(TraineeBean bean)throws TraineeException;
	
	public List<TraineeBean> viewAllTrainees()throws TraineeException;
	
	public TraineeBean deleteTrainee(int traineeId)throws TraineeException;
	
	public boolean updateTrainee(TraineeBean bean)throws TraineeException;
}
