package com.trainee.service;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.dao.ITraineeeDao;
import com.trainee.dao.TraineeDaoImpl;

public class TraineeServiceImpl implements ITraineeService {
	ITraineeeDao dao;
	
	
	public TraineeServiceImpl() {
		dao=new TraineeDaoImpl();
				
	}

	@Override
	public List<TraineeBean> getAllTrainees() {
		return dao.getAllTrainees();
	}

	@Override
	public TraineeBean getTrainee(int id) {
		return dao.getTrainee(id);
	}

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		return dao.addTrainee(trainee);
	}

	@Override
	public TraineeBean deleteTrainee(int id) {
		return dao.deleteTrainee(id);
	}

}
