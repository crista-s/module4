package com.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;
@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		int id=0;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getTraineeId();
		} catch (Exception e) {
			throw new TraineeException("unable to persist in dao layer :"+e.getMessage());
		}
		return id;
	}

	@Override
	public List<TraineeBean> viewAllTrainee() throws TraineeException {
		List<TraineeBean> list=null;
		try {
			TypedQuery<TraineeBean> query=entityManager.createQuery("From TraineeBean",TraineeBean.class );
			list = query.getResultList();
		} catch (Exception e) {
			throw new TraineeException("unable to fetch employee records in dao layer"+e.getMessage()); 
		}
		return list;
	}
	

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TraineeException {
		TraineeBean bean;
		try {
			bean = entityManager.find(TraineeBean.class, traineeId);
			entityManager.remove(bean);
		} catch (Exception e) {
			throw new TraineeException("unable to delete trainee records in dao layer"+e.getMessage());
		}
		return bean;
	}

	@Override
	public boolean updateTrainee(TraineeBean bean) throws TraineeException {
		try {
			bean = entityManager.merge(bean);
			} catch (Exception e) {
			throw new TraineeException("unable to delete trainee records in dao layer"+e.getMessage());
		}
		return true;
	}

	
}
