package com.trainee.dao;

import java.util.List;

import com.trainee.bean.TraineeBean;

public interface ITraineeeDao {

	

		public List<TraineeBean> getAllTrainees();
		public TraineeBean getTrainee(int id);
		public TraineeBean addTrainee(TraineeBean trainee);
		public TraineeBean deleteTrainee(int id);
	

}
