package com.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trainee.bean.TraineeBean;
import com.trainee.dao.ITraineeeDao;
import com.trainee.dao.TraineeDaoImpl;
import com.trainee.exception.TraineeException;
@Service
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	private ITraineeeDao dao;
	
	
	
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		
		return dao.addTrainee(bean);
	}

	@Override
	public List<TraineeBean> viewAllTrainees() throws TraineeException {
		
		return dao.viewAllTrainee();
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(traineeId);
	}

	@Override
	public boolean updateTrainee(TraineeBean bean) throws TraineeException {
		
		return dao.updateTrainee(bean);
	}

}
