package com.author.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import com.author.bean.AuthorBean;
import com.author.exception.AuthorException;
import com.author.service.AuthorServiceImpl;
import com.author.service.IAuthorService;

public class ClientAuthor {

	public static void main(String[] args) {
		AuthorBean bean=new AuthorBean();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		IAuthorService authorService=new AuthorServiceImpl();
		
		while (true) {
			System.out.println(
					"Select your option:\n1.Add Author\n2.Delete Author\n3.Find Author\n4.Display all authors\n5.Update Phone\n6.Exit");
			Scanner in = new Scanner(System.in);
			int ch = in.nextInt();
			switch (ch) {
			case 1:

				System.out.println("Enter the first name");
				String name;
				try {
					name = br.readLine();
					bean.setAuthorFirstName(name);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("Enter the middle name");
				try {
					name = br.readLine();
					bean.setAuthorMiddleName(name);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("Enter the last name");
				try {
					name = br.readLine();

					bean.setAuthorLastName(name);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("Enter the phone number");
				int num = in.nextInt();

				bean.setAuthorPhone(num);

				try {
					int authourId = authorService.addAuthor(bean);
					System.out.println("The author has been inserted with authour id:" + authourId);
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 2:

				System.out.println("Enter the authour id");
				int authorId = in.nextInt();
				try {
					bean = authorService.deleteAuthor(authorId);
					if (bean != null) {
						System.out.println("Record deleted!!\n The deleted record is:");
						System.out.println("Authour Id:" + bean.getAuthorId());
						System.out.println("Authour Name:" + bean.getAuthorFirstName() + " "
								+ bean.getAuthorMiddleName() + " " + bean.getAuthorLastName());
						System.out.println("Authour Phone number:" + bean.getAuthorPhone());
					} else {
						System.out.println("Authour is not present");
					}
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 3:

				System.out.println("Enter the authour id");
				int authId = in.nextInt();
				try {
					bean = authorService.findAuthor(authId);
					if (bean != null) {
						System.out.println("Author Details:");
						System.out.println("Authour Id:" + bean.getAuthorId());
						System.out.println("Authour Name:" + bean.getAuthorFirstName() + bean.getAuthorMiddleName()
								+ bean.getAuthorLastName());
						System.out.println("Authour Phone number:" + bean.getAuthorPhone());
					} else {
						System.out.println("Authour is not present");
					}
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				try {
					List list = authorService.viewAllAuthors();
					if (list != null) {
						for (Object obj : list) {

							AuthorBean abean = (AuthorBean) obj;
							System.out.println(abean.getAuthorId() + "\t" + abean.getAuthorFirstName() + " "
									+ abean.getAuthorMiddleName() + " " + abean.getAuthorLastName() + "\t"
									+ abean.getAuthorPhone() + "\n");
						}
					}
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
				break;
				
			case 5:
				System.out.println("Enter the authour id");
				int aId = in.nextInt();
				System.out.println("Enter new phone Number:");
				int phone = in.nextInt();
				try {
					bean = authorService.updateAuthor(aId,phone);
					if (bean != null) {
						System.out.println("The phone number has been Updated. ");
						System.out.println("Author Details after updation:");
						System.out.println("Authour Id:" + bean.getAuthorId());
						System.out.println("Authour Name:" + bean.getAuthorFirstName() + bean.getAuthorMiddleName()
								+ bean.getAuthorLastName());
						System.out.println("Authour Phone numbe.r:" + bean.getAuthorPhone());
					} else {
						System.out.println("Authour is not present");
					}
				} catch (AuthorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 6:
				System.out.println("Closing..........Thank you. Bye!!!");
				System.exit(0);

			}
		}

	}

}
