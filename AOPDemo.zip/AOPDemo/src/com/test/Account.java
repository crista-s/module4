package com.test;

public class Account {
	public void withdraw()
	{
		System.out.println("withrdraw called");
	}

}
